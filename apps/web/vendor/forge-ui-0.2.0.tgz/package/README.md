# forge-ui

A modern React component library built with **React 19**, **SCSS Modules**, **TypeScript**, and **class-variance-authority**. Drop-in for any web app, fully themable through CSS variables, icons via **Material Symbols Rounded**, and showcased with **Storybook**.

## Stack

- React 19 + TypeScript + Vite
- SCSS Modules (compiled by Vite via `sass-embedded`) — scoped styles, no global collisions
- HSL CSS variables for theming (light / dark / system)
- `class-variance-authority` for variant APIs
- `clsx` for safe class composition
- Material Symbols Rounded for icons (rendered by name)
- Storybook v10 for documentation and visual testing
- Native HTML semantics + ARIA — no third-party UI runtime

## Components

### Primitives
Button · Input · Textarea · Label · Badge · Card · Avatar · AvatarGroup · Spinner · Skeleton · Divider · Icon

### Forms
Checkbox · Radio + RadioGroup · Switch · MultiSelect (searchable, with removable chips) · FileUpload (drag-drop files & folders)

### Feedback
Alert · Progress · Toast (with `useToast` hook + provider)

### Overlays
Dialog (focus-trap, portal) · DropdownMenu (keyboard nav) · Tooltip

### Navigation
Tabs (keyboard-driven, h/v) · Breadcrumb

### Data display
List · ListItem

### Theming
ThemeProvider — light / dark / system, persisted to localStorage

## Icon API

Every component that takes an icon (`Button.leftIcon`, `Input.leftIcon`, `Alert.icon`, `DropdownMenuItem.icon`, `BreadcrumbItem.icon`, `ListItem.icon`, …) accepts either a `ReactNode` or a Material Symbols Rounded **icon name string**:

```tsx
<Button leftIcon="add">New project</Button>
<Input leftIcon="search" placeholder="Search…" />
<Alert icon="warning" variant="warning">…</Alert>
<DropdownMenuItem icon="logout" destructive>Sign out</DropdownMenuItem>
```

Use `<Icon name="..." size="md" weight={500} fill={1} />` directly for full control over the icon's font-variation axes.

## Scripts

```bash
npm install          # install deps
npm run dev          # showcase app at http://localhost:5173
npm run storybook    # Storybook at http://localhost:6006
npm run build        # type-check + production build
```

## Reusing in another app

1. Copy `src/lib/` and `src/styles/` into your project.
2. Install peer deps:
   ```bash
   npm install class-variance-authority clsx sass-embedded
   ```
3. Import the global stylesheet once at your entry point:
   ```ts
   import '@/styles/globals.scss'
   ```
4. Add the Material Symbols Rounded font link in your HTML head.
5. Wrap your app with the providers you need:
   ```tsx
   import { ThemeProvider, ToastProvider } from '@/lib'

   <ThemeProvider defaultTheme="system">
     <ToastProvider>
       <App />
     </ToastProvider>
   </ThemeProvider>
   ```

## Theming

Every color, radius, and font is a CSS variable in `src/styles/_tokens.scss`. To rebrand, override the HSL tokens once:

```css
:root {
  --primary: 200 90% 50%;
  --ring: 200 90% 50%;
  --radius-md: 0.75rem;
}
```

Components pick up the new values automatically — no rebuild needed.

## File layout

```
src/
├── styles/
│   ├── _tokens.scss          # HSL variables, light + dark
│   ├── _mixins.scss          # focus-ring etc.
│   ├── _animations.scss      # @keyframes
│   └── globals.scss          # base styles
├── App.tsx                   # showcase page
├── App.module.scss
├── main.tsx                  # entry, wraps in ThemeProvider
└── lib/
    ├── index.ts              # public barrel export
    ├── utils.ts              # cn() helper
    ├── Introduction.mdx      # storybook landing
    └── components/
        ├── *.tsx             # one component per file
        ├── *.module.scss     # scoped styles
        └── *.stories.tsx     # Storybook story per component
```
